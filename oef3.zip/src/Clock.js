import React, {useState, useEffect} from 'react';

// function Clock(){
//     const [time, setTime] = useState(new Date())
//     // useEffect mount en unmount automatisch
//     useEffect(() => {
//         setInterval(tick, 1000);
//     })
//     const tick = () => {
//         setTime(new Date());
//     }
//     return (
//     <h1>{time.toLocaleTimeString()}</h1>
//     )
// }

class Clock extends React.Component {
    intervalID = 0;
    state = {
        time: new Date()
    }
    // is op scherm: load
    componentDidMount(){
        this.intervalID = setInterval(this.tick, 1000)
    }
    // is niet op scherm: unload
    componentWillUnmount(){
        clearInterval(this.intervalID);
    }
    tick = () => {
        this.setState({
            time: new Date()
        })
    }
    render(){
        return(
        <h1>{this.state.time.toLocaleTimeString()}</h1>
        )
    }
}

export default Clock;