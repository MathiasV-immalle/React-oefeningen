import React from 'react';
import cities from './cities.json';

class CityList extends React.Component {
    state = {
        zoek: null
    }

    search = (event) => {
        this.setState({
            zoek: event.target.value
        })
    }

    render(){
        return (
            <div>
                <input type="text"placeholder="Search"onChange={this.search}></input>
                <ul>
                    {cities.map((city, index) => {
                        {/*zoek is default null! includes() zorgt ervoor dat de lijst wordt gefilterd op de karakters die je ingeeft */}
                        if(this.state.zoek === null || city.Name.toLowerCase().includes(this.state.zoek.toLowerCase())){
                            return <li className={(this.props.selectedCity === city.Name ? 'selectedCity' : null)} key={index} onClick={() => this.props.onChange(city.Lat, city.Lon, city.Name)}>{city.Name}</li>
                        }
                    })}
                </ul>
            </div>
        )
    }
}

export default CityList;