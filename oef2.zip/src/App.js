import React from 'react';
import logo from './logo.svg';
import './App.css';
import CityList from './CityList';
import Map from 'pigeon-maps';
import Marker from 'pigeon-marker';

class App extends React.Component {
  state = {
    lat: 50.879,
    lon: 4.6997,
    selectedCity: "Leuven"
  }
  handleChange = (lat, lon, selectedCity) => {
    this.setState({
      lat: lat,
      lon: lon,
      selectedCity: selectedCity
    })
  }
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <div class="flex">
            <CityList onChange={this.handleChange} selectedCity={this.state.selectedCity} />
            <Map center={[this.state.lat, this.state.lon]} zoom={12} width={600} height={400}>
              <Marker anchor={[this.state.lat, this.state.lon]} payload={1} onClick={({ event, anchor, payload }) => { }} />
            </Map>
          </div>
        </header>
      </div>
    );
  }
}

export default App;

{/* npm start, npm install --save pigeon-maps, npm install --save pigeon-marker */ }